package com.eurostar.repository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.eurostar.entity.SampleEntity;

@Repository
public interface SampleEntityRepository extends CrudRepository<SampleEntity, Long>{

               

               

 

}