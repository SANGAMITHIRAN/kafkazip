package com.eurostar.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.eurostar.producer.Producer;

@RestController
@RequestMapping("/kafkarestcontroller")
public class KafkaRestController {
	
	@Autowired
	 private  Producer producer;
	

	
	    @PostMapping("/send")
	    public ResponseEntity<String> send(@RequestBody(required = false) String requestBody) {
			try {
				System.out.println("Inside Producer:::::");
				if(requestBody!=null) {
					producer.send(requestBody);
				}else
	    	//producer.send(":::::EUROSTAR Message check :: ");
	    	
	    	System.out.println("::::::::::;;Message sent:::::::::::");
		} catch (Exception e) {
			return new ResponseEntity<String>("Producer Message Failed"+e.getMessage(), HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<String>(" Message Sent Successfully", HttpStatus.CREATED);
		
	    }
}
