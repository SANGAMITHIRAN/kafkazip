package com.eurostar.producer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.eurostar.kafka.ApplicationConstant;

@Service("producer")
public class Producer {
	
		@Autowired
	    private  KafkaTemplate<String, Object> kafkaTemplate;

	    public void send(String message){
	    	try {
	        System.out.println("Payload Producer: {}" +message);
	        System.out.println("topicName" +ApplicationConstant.TOPIC_NAME);
	        kafkaTemplate.send(ApplicationConstant.TOPIC_NAME, message);
	    	} catch (Exception e) {
				System.out.println("Error at Producer message"+e.getMessage());
			}
	    }
}
