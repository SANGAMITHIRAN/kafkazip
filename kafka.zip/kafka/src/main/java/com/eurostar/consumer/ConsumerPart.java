package com.eurostar.consumer;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import com.eurostar.entity.SampleEntity;
import com.eurostar.kafka.ApplicationConstant;
import com.eurostar.repository.SampleEntityRepository;

@Component
public class ConsumerPart {
	
	@Autowired(required = false)
	private SampleEntityRepository sampleEntityRepository;

	@KafkaListener(groupId = ApplicationConstant.GROUP_ID_JSON, topics = ApplicationConstant.TOPIC_NAME, containerFactory = ApplicationConstant.KAFKA_LISTENER_CONTAINER_FACTORY)
    public void consume(ConsumerRecord<String, String> payload){
    	
    	try {
		  System.out.println("::::::::::::::INSIDE CONSUMER ::::::::::::::");
    	
        System.out.println("key:::;" +payload.key());
        System.out.println("Headers::::" +payload.headers());
        System.out.println("VALUE::::::::--->"+payload.value());
        SampleEntity sampleEntity=new SampleEntity();
        sampleEntity.setCondition(true);
        sampleEntity.setName("sanga");
        sampleEntity.setSampleId(2);
        sampleEntityRepository.save(sampleEntity);
    	}catch(Exception ex) {
    		
    		System.out.println("Exception at consume:::::"+ex.getMessage());
    	}

    }
}
